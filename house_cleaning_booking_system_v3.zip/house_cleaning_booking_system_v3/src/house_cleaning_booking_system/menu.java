
package house_cleaning_booking_system;


public class menu extends javax.swing.JFrame {

    
     public menu() {
        initComponents();
    }

   
        
     
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollBar1 = new javax.swing.JScrollBar();
        jLabel3 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        pi = new javax.swing.JButton();
        schedule = new javax.swing.JButton();
        BOOKINGS = new javax.swing.JButton();
        log_out = new javax.swing.JButton();
        so1 = new javax.swing.JButton();
        bh = new javax.swing.JButton();
        tc1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        jLabel3.setFont(new java.awt.Font("Serif", 1, 14)); // NOI18N
        jLabel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2), "MY ACCOUNT", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Serif", 1, 14), new java.awt.Color(255, 255, 255))); // NOI18N

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(204, 0, 51));
        jPanel6.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createEtchedBorder(null, new java.awt.Color(102, 102, 102)), javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(51, 51, 255))));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("HOUSE CLEANING BOOKING SYSTEM");
        jLabel5.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2), "WELCOME TO", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Serif", 1, 14), new java.awt.Color(255, 255, 255))); // NOI18N
        jPanel6.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(23, 8, 760, 80));

        getContentPane().add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 100));

        jPanel2.setBackground(new java.awt.Color(233, 108, 108));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pi.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        pi.setText("PERSONAL INFO");
        pi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        pi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                piActionPerformed(evt);
            }
        });
        jPanel2.add(pi, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 50, 270, 39));

        schedule.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        schedule.setText("SCHEDULE");
        schedule.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        schedule.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                scheduleActionPerformed(evt);
            }
        });
        jPanel2.add(schedule, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 160, 270, 40));

        BOOKINGS.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        BOOKINGS.setText("BOOKING");
        BOOKINGS.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BOOKINGS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BOOKINGSActionPerformed(evt);
            }
        });
        jPanel2.add(BOOKINGS, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 100, 270, 40));

        log_out.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        log_out.setText("LOG - OUT");
        log_out.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        log_out.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                log_outActionPerformed(evt);
            }
        });
        jPanel2.add(log_out, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 340, 310, 40));

        so1.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        so1.setText("SERVICE OFFER");
        so1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        so1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                so1ActionPerformed(evt);
            }
        });
        jPanel2.add(so1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 210, 270, 40));

        bh.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        bh.setText("BOOKINGS HISTORY");
        bh.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        bh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bhActionPerformed(evt);
            }
        });
        jPanel2.add(bh, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 270, 270, 40));

        tc1.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        tc1.setText("TERMS & CONDITION");
        tc1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tc1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tc1ActionPerformed(evt);
            }
        });
        jPanel2.add(tc1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 320, 270, 40));

        jLabel1.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 5, true), "MY ACCOUNT", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Verdana", 1, 14))); // NOI18N
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 10, 360, 380));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 800, 400));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void scheduleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_scheduleActionPerformed
   MY_SCHEDULE sched = new MY_SCHEDULE();
   sched.setVisible(true);
   this.dispose();
    }//GEN-LAST:event_scheduleActionPerformed

    private void BOOKINGSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BOOKINGSActionPerformed
    BOOKING book = new BOOKING();
    book.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_BOOKINGSActionPerformed

    private void so1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_so1ActionPerformed
       SERVICE_OFFER offer= new SERVICE_OFFER();
       offer.setVisible(true);
       this.dispose();
    }//GEN-LAST:event_so1ActionPerformed
      
    private void piActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_piActionPerformed
    PERSONAL_INFO info = new PERSONAL_INFO();
        info.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_piActionPerformed

    private void bhActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bhActionPerformed
     BOOKING_HISTORY history = new BOOKING_HISTORY();
     history.setVisible(true);
     this.dispose();
    }//GEN-LAST:event_bhActionPerformed

    private void log_outActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_log_outActionPerformed
        System.exit(0);
    }//GEN-LAST:event_log_outActionPerformed

    private void tc1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tc1ActionPerformed
      TERMSandCONDITION tc = new TERMSandCONDITION();
      tc.setVisible(true);
      this.dispose();
    }//GEN-LAST:event_tc1ActionPerformed
       
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new menu().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BOOKINGS;
    private javax.swing.JButton bh;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollBar jScrollBar1;
    private javax.swing.JButton log_out;
    private javax.swing.JButton pi;
    private javax.swing.JButton schedule;
    private javax.swing.JButton so1;
    private javax.swing.JButton tc1;
    // End of variables declaration//GEN-END:variables

    }
